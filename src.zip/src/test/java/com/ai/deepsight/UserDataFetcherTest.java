package com.ai.deepsight;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserDataFetcherTest {

    @Test
    void dummyTestToVerifyJUnitWorks() {
        assertEquals(2, 1 + 1);
    }
}
