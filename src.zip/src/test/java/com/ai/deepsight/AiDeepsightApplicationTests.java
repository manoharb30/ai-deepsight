package com.ai.deepsight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiDeepsightApplicationTests {

    @Test
    void contextLoads() {
    }

}
