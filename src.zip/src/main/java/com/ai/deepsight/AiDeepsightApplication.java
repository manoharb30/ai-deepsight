package com.ai.deepsight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AiDeepsightApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiDeepsightApplication.class, args);
    }
}
